// server.js
// ExpressJS app with GET, POST, PUT, and DELETE routes

const express = require('express');
const app = express();

// Middleware to parse JSON body data
app.use(express.json());

// Sample in-memory data (you can imagine this as a mini database)
let students = [
  { id: 1, name: "Jassu", course: "ReactJS" },
  { id: 2, name: "jaswanth", course: "NodeJS" }
];

// ------------------- ROUTES -------------------

// GET - Read all students
app.get('/students', (req, res) => {
  res.status(200).json(students);
});

// POST - Add a new student
app.post('/students', (req, res) => {
  const newStudent = req.body;
  students.push(newStudent);
  res.status(201).json({
    message: 'Student added successfully ✅',
    students
  });
});

// PUT - Update a student by ID
app.put('/students/:id', (req, res) => {
  const studentId = parseInt(req.params.id);
  const updatedData = req.body;
  const index = students.findIndex(s => s.id === studentId);

  if (index !== -1) {
    students[index] = { ...students[index], ...updatedData };
    res.status(200).json({
      message: 'Student updated successfully ✏️',
      student: students[index]
    });
  } else {
    res.status(404).json({ message: 'Student not found ❌' });
  }
});

// DELETE - Remove a student by ID
app.delete('/students/:id', (req, res) => {
  const studentId = parseInt(req.params.id);
  students = students.filter(s => s.id !== studentId);
  res.status(200).json({
    message: 'Student deleted successfully 🗑️',
    remainingStudents: students
  });
});

// ------------------- START SERVER -------------------
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
